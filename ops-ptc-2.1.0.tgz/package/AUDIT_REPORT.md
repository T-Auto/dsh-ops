# ops-ptc 2.0.1 审计与验证报告

## 结论与范围

本轮审计覆盖 `src/ptc/`、MCP stdio、CLI、发布元数据及真实 dsh-ops 接入契约。修复集中在改写正确性、提交前审计、并发变更拒绝、进程资源约束及宿主接口适配。未 push、未 publish，未替换当前宿主插件。

已验证的是独立包引擎及 adapter 对真实原包 schema、类型和 ToolRuntime 的兼容性。生产宿主的可信执行桥没有接线，不能将本包视为原生 discovery 自动发现或权限隔离的直接替代品。接线要求见 [HOST_INTEGRATION.md](HOST_INTEGRATION.md)。

环境：Windows x64、Node v24.22.1、AMD Ryzen 7 9700X。package engines 声明 Node >=18，不代表已完成 Node18、Linux 或 macOS 验收。原包验证对象为已安装的 dsh-ops 0.4.1，宿主依赖来自本机真实 @deepseek-ai/dsh-tools 与 @deepseek-ai/cordis。

## 方法与证据链

以复现 → 修复 → 回归为主线，保留固定输入和真实落盘断言。AST 诊断对比、Unicode/CRLF、已有语法错误、变长补丁、二进制保持、临时文件冲突、hash/snapshot 失配、失败清理及协议边界均有独立脚本。性能测试与正确性门槛分离，移除依赖单机固定毫秒数和固定倍率的 smoke 断言。

本轮没有执行全量第三方依赖 CVE/SCA 联网查询，也没有对 OS、Everything 服务或外部二进制实施完整审计。不要把源码审计结论解释为依赖零漏洞证明。

## 发现与修复

| 编号 | 优先级 | 复现的缺陷或风险 | 修复路径 | 回归证据 |
| --- | --- | --- | --- | --- |
| F01 | 高 | variadic 捕获拼接丢逗号、注释或空白，产生错误候选；未绑定模板变量未拒绝 | `inproc.ts` 从原始捕获范围提取，空捕获保留空串，未绑定变量报错 | `scripts/ast-regression.mjs` |
| F02 | 高 | 同名符号不同声明形式只命中部分，歧义编辑可选错定义 | 汇总定义形态、去重排序，歧义熔断 | AST + safety 回归 |
| F03 | 高 | 只比较错误数量会让修好一处旧错误掩盖新错误 | `astdiff.ts` 以诊断身份、偏移映射及未改区域比较；拒绝新增错误 | AST 回归中相同计数/不同错误、位移旧错误案例 |
| F04 | 高 | 多文件执行到后续错误时，前面的文件已经被修改；写入缺快照/锁/独占临时文件 | 全部候选预审计；`safe-write.ts` 协作锁、独占随机临时文件、前后 snapshot、mode 保留及 rename | `scripts/safety-regression.mjs` |
| F05 | 中 | 枚举多 roots 超全局上限，缓存复用错误 limit/截断标记；返回数组可污染缓存 | 全局去重和上限、cache key 含策略/上限等、保留 truncation、克隆结果 | safety 回归，cap2 → cap20 |
| F06 | 中 | null、非法 mode/NaN 和错误参数进入公开引擎路径，可能崩溃或意外 apply | inproc 与 pipeline 入口校验，错误早返回；限定 scanBudget/limit | safety + pipeline 回归 |
| F07 | 高 | 旧 pipeline 在落盘后才审计；解析失败可能已经触发写入 | 对同一 snapshot 计算改写；支持语言先审 AST 诊断，再审内存 difftastic 候选，最后提交 | `scripts/pipeline-regression.mjs` |
| F08 | 高 | 变长文件恢复使用 original.length 替换 current 区间，恢复可能留尾或越界 | restore 使用当前文件长度并保留 sha 守护 | pipeline 回归 grow/shrink + hash 失配 |
| F09 | 中 | 临时目录 pid/时间命名碰撞，difftastic 抛错路径泄漏临时文件 | 随机 mkdtemp，finally 清理 owned 目录 | pipeline 回归 |
| F10 | 高 | worker stdin/目标/输出无界、弱范围/base64/hash 校验、临时名碰撞、unsafe copy 分支 | 16MiB 输入/目标/输出约束，10000 edits，上下界与编码校验，强制64hex preimage hash；拒绝 atomic:false；随机 wx、锁、晚 snapshot、清理 | `scripts/worker-regression.mjs` |
| F11 | 中 | stdout 超预算静默返回截断成功，stderr 持续写直到超时 | `proc.ts` stdout/stderr 共享预算，超限立即终止并报 E_OUTPUT_LIMIT | `scripts/protocol-regression.mjs` |
| F12 | 中 | MCP null 崩溃，notification 回包、原型 handler、EOF/UTF8 分片、业务错误未 isError、无界输入/在途调用/输出积压 | `mcp.ts` 协议校验；1MiB帧、32在途、8MiB应用层输出预算，严格自有 handler、EOF drain、业务错误标记 | protocol回归：初始36项基线4通过/32失败；增补并发及stalled Writable后38项通过 |
| F13 | 高（接入条件） | 自定义 handlers 元数据不等于原包 ToolDefinition，cwd 不构成权限控制 | 新增 `adapter.ts`、Outcome 转换、真实 ToolRuntime 注册清理；缺 session/policy/invoke 关闭执行 | `scripts/host-compat-smoke.mjs` 88条断言 + strict consumer 编译 |
| F14 | 中 | smoke 依赖本机真实项目，固定10倍/5ms性能门槛容易误报 | 自包含四 return fixture，保留有明确契约的可选输入；性能改观测 | `scripts/inproc-smoke.mjs` 18条正确性检查 |

`astdiff.ts` 中历史字段名 startByte/endByte 在 napi 审计域实际表示 UTF-16 index；CLI Edit.byteOffset 使用 UTF-8。pipeline 在跨域调用处显式转换。Unicode、emoji、CRLF 与字节 unchangedRatio 均覆盖测试。

## 验证结果

`npm run verify` 与真实原包 `test:host` 均退出0；`git diff --check` 退出0。

| 检查 | 实测结果 |
| --- | --- |
| typecheck / build | 通过 |
| pipeline / MCP / inproc smoke | 7 / 5 / 18 项通过 |
| safety / AST / worker 回归 | 15 / 19 / 16 项通过 |
| protocol / pipeline 回归 | 38 / 22 项通过 |
| 真实 dsh-ops 0.4.1 | 88 条断言及 strict consumer 编译通过 |
| 生产 tarball 独立安装 | 使用 omit=dev、ignore-scripts；验收记录见 audit/package-install.json |

统一日志为 `audit/final-verify.log`、`audit/host-compat.log`。安装检查在独立目录运行，并在子进程验证引擎/MCP，退出后释放 Windows napi DLL 再清理；不会借用仓库开发依赖。最终包的 SHA-256 单独保存在 `audit/release.json`，避免将包自身哈希写入包内造成循环。

标准执行：

```bash
npm ci
npm run verify
npm run test:host -- --ops-root OPS_ROOT --host-root HOST_NODE_MODULES
npm run bench:audit
npm pack
```

`verify` 包含 typecheck、build、旧 pipeline smoke、MCP smoke、自包含 inproc smoke，以及十二组独立回归。外部 pipeline/strict 需要已安装 ast-grep 和 difftastic；Everything 查询需要可用 es/服务。纯 walk inproc 的生产安装验收单独运行，不借用仓库 devDependencies。

## 性能复测

固定输入为120个合成 TS 文件，目标函数包含4个 return，并包含中文、emoji 和 CRLF。inproc 与 pipeline 使用同一符号域/模板/preview 模式，独立 apply 后逐字节比较。cold 每次新 Node 进程，包含启动和 require；warm 预热后交替运行，报告9次样本中位、最小及最大。cold 仅指进程冷态，没有清空 OS 文件缓存。

本轮实测 cold 中位数：inproc 160.605ms、pipeline 355.813ms（各5次）；warm 中位数：inproc 1.233ms、pipeline 197.734ms（各9次）。walk枚举 fresh/cache 中位数为0.313/0.010ms（各9次）。两条引擎 apply 输出逐字节一致。详见生成的 `audit/benchmark.json`（仓库内，不随安装包分发），数据包含环境、fixture SHA-256、所有样本、枚举 fresh/cache 对照及输出一致性。该 fixture 不能证明通用性能倍率或 Everything 文件数交叉点，返回字节数也不能直接换算为所有模型的 token 节省率。旧 BENCH/SMALL_TREE/VS_NATIVE 文档仅为历史样本。

## 2.0.5 精简与产物形态审计

安装包从 134165 收到 65313 字节（−51.3%），只保留 `dist/` 与四份文档。三条判据由 `scripts/dist-shape-regression.mjs` 每次回归时复核：

1. **去注释只发生在 `.js`**：11 个运行时文件不含块注释；`.d.ts` 由第二遍 `--emitDeclarationOnly` 重新生成，JSDoc 全部保留（8 份有内容的声明逐份断言）。
2. **公开导出集合不变**：`dist` 每个可加载模块的导出键与冻结的 2.0.4 构建逐模块比对（`cli`/`mcp` 顶层接管 stdio，不同进程内 require）。
3. **包内容契约**：`files` 白名单固定为五项；消费端验收额外断言 `audit/`、`scripts/`、`src/` 与分组报告不在包内，且 `dist` 解包 < 200 KiB。

功能等价由 15 个固定场景的完整返回字段 + 落盘字节比对证明（`audit/perf-round6/comparison-205-vs-204.json`），不是靠人工 review 推断。

## 仍存在的边界

1. **可信宿主桥未接线**：adapter 已通过真实接口与注册测试，但不能直接把裸 handler 绑定 invoke 冒充沙箱。路径、凭证隔离、取消传播和提交前授权重验由宿主实现。
2. **并发不是 CAS**：合作方使用同名锁可以互斥，前后 snapshot 可拒绝已观察到的变更；不合作的外部 writer 仍有最后检查与 rename 之间的竞态窗口。没有文件系统 compare-and-swap 保证。
3. **多文件不是事务**：提交前审计全部候选不代表 IO 提交原子化。中途写入失败可部分成功，必须核实 committed/partial；不能宣称自动全局回滚。
4. **解析不等于语义**：TypeScript parseDiagnostics 不做类型或业务正确性验证；tree-sitter 容错解析可能漏错，difftastic 仅给结构差异。非 TS/JS 的语法保证受对应解析器约束。
5. **枚举不等于完整搜索**：自动策略、上限、30秒缓存、启发式预筛和预算可能导致剪枝或索引陈旧。truncated/pruned 必须保留；找不到不能自动推断不存在。
6. **资源限制分层**：worker 有固定16MiB边界；MCP单帧1MiB、在途32个、应用层stdout待发预算8MiB；子进程stdout/stderr共享独立预算。Windows同步pipe可能在write内阻塞，writableLength限额不提供慢reader超时保证。inproc 对大文件有预检查，但 stat→read 并非原子操作，不能宣称在任意外部并发下有严格总进程内存上界。
7. **崩溃锁和目录竞态**：进程被硬终止时可能留下 stale lock；删除锁前应确认原 owner 已终止，当前不自动按时间抢锁。父目录 symlink/junction 替换不在本锁机制的保护范围内。
8. **元数据保留有限**：保留 mode 不代表完整保留 Windows ACL、ADS、扩展属性、owner 或全部时间戳；硬链接与符号链接替换会被拒绝。
9. **取消能力有限**：宿主 adapter 派发前检查取消，超时声明不等于能够硬停同步进程内工作；真实 invoke 必须负责停止下游并收集副作用状态。
10. **平台与版本**：本轮没有跨平台/Node18验收；外部二进制或 dsh-ops 其它版本仍需运行兼容回归。

## 交付与部署

交付物为源码修复、回归脚本、报告、接线文档、固定 benchmark 数据及本地 tarball。宿主现有工具未被替换，仓库未提交/push，registry 未 publish。先在独立目录安装 tarball，核对纯生产依赖下的 inproc + MCP 路径，再由集成方实现可信宿主桥。
