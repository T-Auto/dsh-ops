# 本地修补 — ops-parallel-read 4.1.4

本包在并入 dsh-ops 后做了一轮审计，下面每条都是在本机复现过的缺陷，不是推测。

## F3 叶子链接检查与 open 之间的替换窗口

**位置**：`ops_parallel_read.js`（`readOne`）

**现象**：目录链走 `assertParentDirs`（逐级 `lstat`），叶子走 `startLeafCheck`（`lstat` 与 `open` 并发）。两次调用之间把普通文件换成 symlink/junction，`lstat` 仍报「普通文件」，而 `open` 已经跟到栏外——原装 Rust 用 `open_nofollow`，这一步是原子的，兼容层不是。

**修补**：`open` 拿到句柄后，用 `fstat` 的 `dev + ino` 与先前 `lstat` 的身份比对，不一致即判定「检查后被替换」，抛 `PATH_RESTRICTED` 并关句柄。两个 `stat` 本来就要付，修补不增加 syscall。

```js
if (leafStat && leafStat.ino !== 0 && stat.ino !== 0
    && (stat.ino !== leafStat.ino || stat.dev !== leafStat.dev)) {
  throw new OpsError('PATH_RESTRICTED', LINK_DENIED + ' (replaced between check and open)');
}
```

## 验证

| 用例 | 结果 |
| --- | --- |
| 24 × 20 行、同一文件重复读 | 2.30 ms/次（修补前 2.05–2.16 ms，差异在噪声内） |
| 工作区内 junction 指向栏外 | `PATH_RESTRICTED`，未读到栏外字节 |
| 普通文件批量读 | `completed`，条目数与行数不变量不变 |

## 未修（设计取舍）

- `concurrency` 默认放开到 32：入参本身限死 32 个文件，FD 峰值天然 <= 32。
- 批级 `linkCache` 缓存的是「进行中的 promise」，不是结果；同一批内同一目录只付一次 `lstat`，跨批不共享——这是为了不引入跨调用的陈旧窗口。

## R12 缺省 limit 由 200 行改为整文件

**位置**：`ops_parallel_read.js`（`COMPAT_DEFAULT_LIMIT`）

**现象**：兼容层照抄了原装的 200 行缺省值。271 行的 `worker.js` 只回 200 行，`status` 仍是
`completed`，`nextOffset` 给了 201 但摘要里没有「少了 71 行」这件事——模型要么漏内容，要么
多花一整轮补读。200 行是给读大文件设的节流，不是 agent 要的「全文」语义。

**修补**：`COMPAT_DEFAULT_LIMIT = COMPAT_MAX_LIMIT`，真正的闸门只剩输出预算（128 KiB JSON）。
显式 `limit` 仍按 1..10000 生效，传 `limit: 200` 的行为与 4.1.4 完全一致。

**数字**（`dsh-ops/lib/file/worker.js`，271 行，`gpt-tokenizer` o200k_base）：

| 口径 | 返回行数 | token | 读取轮次 |
| --- | --- | --- | --- |
| 4.1.4 缺省 | 200 / 271 | 2,625 | 2 |
| 4.1.5 缺省 | 270 / 271 | 3,713 | 1 |

一次调用多带 1,088 token，省掉一整轮上下文重发。
