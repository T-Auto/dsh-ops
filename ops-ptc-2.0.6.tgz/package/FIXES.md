# 本地修补 — ops-ptc 2.0.5

并入 dsh-ops 后审计出四类缺陷，全部在本机复现并修完。

## P1 重解析点逃逸（严重）

**位置**：`dist/ptc/inproc.js`（`narrow` / `inprocLocate` / `inprocRefactor` 的读取点）、新增 `dist/ptc/reparse.js`

**现象**：引擎用 `statSync` + `readFileSync` 直接读调用方给的名字。工作区内放一个 junction 指向栏外，`ws/link/leak.ts` 在词法上完全在栏内、过得了凭据围栏（名字里没有凭据）也过得了锚定，内核在 open 时才把 `link` 解析到别处。实测：`ptc_locate`、`ptc_inproc` 都能读到栏外文件并返回符号。

**修补**：新增 `reparseEscape(target)`，从叶子逐级 `lstat`（遇到卷根停止），命中任何 symlink/junction 即返回该组件。三个读取点在读之前调用，命中则跳过；宿主适配层对调用方**点名**的路径另有一道，返回 `PATH_RESTRICTED` 而不是静默跳过。

## P2 `esPath` 永远解析不到 vendor

**位置**：`dist/ptc/proc.js`

**现象**：`defaultConfig` 把 `esPath` 定为字面量 `'./es.exe'`。它带路径分隔符，spawn 时按进程 cwd 相对解析，于是候选清单里本该命中的 `vendor/es.exe` 根本没被走到——`ptc_find` / `ptc_refactor` 稳定报 `E_BIN_MISSING: 找不到可执行文件: ./es.exe`，即使二进制就在包里。

**修补**：新增 `pickExistingEs()`，按 `esCandidates()` 的顺序挑第一个**存在**的绝对候选；裸命令名（`es`、`es.exe`）保持原样交给 PATH。`defaultConfig` 改用该函数。

## P3 `ptc_locate` 默认不扫 JavaScript

**位置**：`dist/ptc/inproc.js`（`inprocLocate` / `inprocRefactor` 的 `ext` 默认值）

**现象**：`req.ext ?? ['ts', 'tsx']`。一个纯 `.js` 的库里 `ptc_locate` 枚举零命中，报 `E_INPROC_NO_MATCH`——但它自己的 `langOf()` 明明支持 `.js`。实测在 dsh-ops 里定位一个 `.js` 里的函数，只枚举到 13 个 `.ts` 候选，直接报「未找到」。

**修补**：默认扩展名改为 `['ts', 'tsx', 'js', 'jsx', 'mjs', 'cjs']`。同一查询修复后枚举 154 个文件、命中 1 处、220 ms。

## P4 `ptc_find` 把目录当文件读

**位置**：`dist/ptc/stages.js`（`everythingFind`）

**现象**：`es.exe` 的索引里目录也是条目，`-path <root>` 加子串查询会把 `node_modules/@dsh-ops` 这种目录吐出来，流水线随后拿它当文件：`E_SANE_UNSUPPORTED_LANG`，`不支持的文件类型: `（扩展名为空）。

**修补**：候选在进入流水线前统一 `stat().isFile()` 过滤，并用同一 `reparseEscape` 去掉重解析点（索引是历史数据，早先建的链接照样能被命中）。

## 附带：`vendor/es.exe`

包内新增 `vendor/es.exe`（Everything CLI 1.1.0.38，262 KB），`esCandidates()` 的第三顺位正好是这个路径，装上即可用，不再需要手工摆二进制。`package.json` 的 `files` 已加 `vendor`。

## 验证

| 用例 | 修补前 | 修补后 |
| --- | --- | --- |
| 工作区内 junction 指向栏外（locate / inproc） | 读到栏外符号 | `PATH_RESTRICTED` |
| `ptc_locate` 找 `.js` 里的 `invokePtc` | `E_INPROC_NO_MATCH`（13 候选） | 命中 1 处，220 ms |
| `ptc_find {query:'ptc-inproc.js'}` | `E_BIN_MISSING` | 命中 1 处，186 ms |
| `ptc_find {query:'dsh-ops'}`（名称查询，无同名文件） | `E_SANE_UNSUPPORTED_LANG`（把目录当文件） | `E_EVERYTHING_NOT_FOUND`（诚实的零命中） |
| `ptc_audit` 自比对 | ok | ok，0 hunk / 1 处改写 |

## 未修（已确认为设计取舍）

- `ptc_find` 的 `query` 是**文件名**查询，不是仓库名；`*.js` 这类通配会取排名第一的文件并在符号不存在时报 `E_SANE_SYMBOL_NOT_FOUND`，不会顺延到下一个候选。要跨文件找符号用 `ptc_locate`（它枚举 + 扫描）。
- `pipeline.js` 的 CLI 入口（`pipeline.js:210`）仍然把 `--es` 缺省值当字面量，只影响命令行用法，不影响宿主内的五个工具。

## R12 inputSchema 描述瘦身

**位置**：`dist/ptc/tools.js`（五个工具各自的 `inputSchema`）

**现象**：五个 schema 合计 2,588 B。这些字节不是「调用一次才算」，它们进的是**每一轮请求**
的常驻工具面：描述越长，每轮对话都在为同一段说明付 token。

**修补**：把 `inputSchema` 里重复的默认值、举例和长括号压成关键词，类型、`enum`、`required`
一个不动，工具的 `description` 也不动（保留给首次选择工具时的语义）。

**数字**：`2,588 B → 2,328 B`（−260 B，−10%），计 640 token。同一批入参在新 schema 下仍全部
通过引擎校验（`mode=apply|preview`、`strategy=auto|walk|everything`、`required` 缺失即
`E_BAD_ARGS`）。
