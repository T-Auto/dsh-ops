/**
 * The credential root cache, which the credential suites cannot guard on this host.
 *
 * `credentialPath` memoises the thirteen `realpath` calls that turn the home directory into denied
 * roots. That was 1.9 ms on every file-tool call — 99% of a warm `symbol_map` — so it is worth a
 * cache, and a cache in a fence is worth a test that runs everywhere.
 *
 * This suite deliberately needs no worker and no grammar: it is the only credential test that
 * executes on a checkout without a native build, and the two suites that do drive the real worker
 * skip there. Everything asserted here is a property of `credentialPath` itself, not of a tool.
 *
 * @module dsh-ops/test/credential-cache
 */

import fs from 'node:fs'
import path from 'node:path'

import { assert, report, TEST_HOME, test } from './lib/harness.mjs'
import { CREDENTIAL_SUFFIXES, DENY_ENV, credentialPath, credentialRoots, resetCredentialCache } from '../lib/credential-policy.js'

/** A fixture tree that is removed afterwards, without the ownership repair the harness cannot do here. */
async function withHome(prefix, body) {
  const dir = fs.mkdtempSync(path.join(TEST_HOME, `${prefix}-`))
  try { return await body(dir) } finally { fs.rmSync(dir, { recursive: true, force: true }) }
}

const deny = (candidate, home, env = {}) => credentialPath(candidate, { home, env })

await test('a cached root list still denies every suffix, its children and the root itself', () => withHome('credential-cache-suffix', async root => {
  const home = path.join(root, 'home')
  fs.mkdirSync(path.join(home, '.ssh'), { recursive: true })
  fs.writeFileSync(path.join(home, '.ssh', 'config'), 'Host *')
  resetCredentialCache()
  for (const suffix of CREDENTIAL_SUFFIXES) {
    const target = path.join(home, suffix, 'leaf')
    const verdict = deny(target, home)
    assert.equal(verdict.denied, true, `${suffix} must deny a child`)
    assert.equal(verdict.matched, suffix)
  }
  assert.equal(deny(path.join(home, '.ssh'), home).denied, true, 'the root itself is inside the fence')
  assert.equal(deny(path.join(home, '.SSH', 'config'), home).denied, true, 'components compare case-insensitively')
  assert.equal(deny(path.join(home, 'notes.txt'), home).denied, false)
  assert.equal(deny(path.join(home, 'ssh-notes.txt'), home).denied, false, 'a name that merely mentions ssh is not a store')
}))

await test('the cache is keyed by home and by the widening variable, so neither answer leaks', () => withHome('credential-cache-key', async root => {
  const first = path.join(root, 'home-a')
  const second = path.join(root, 'home-b')
  fs.mkdirSync(first, { recursive: true })
  fs.mkdirSync(second, { recursive: true })
  resetCredentialCache()
  // Warm the cache on the first home, then ask the same question for a path under it but keyed to
  // the second: a cache that ignored the home would answer `true` here.
  assert.equal(deny(path.join(first, '.ssh', 'config'), first).denied, true)
  assert.equal(deny(path.join(first, '.ssh', 'config'), second).denied, false, 'home-a roots must not answer for home-b')
  assert.equal(deny(path.join(first, '.ssh', 'config'), first).denied, true, 'and home-a keeps its own answer')

  const vault = path.join(first, 'vault')
  assert.equal(deny(path.join(vault, 'token'), first).denied, false)
  assert.equal(deny(path.join(vault, 'token'), first, { [DENY_ENV]: vault }).denied, true, 'the variable widens')
  assert.equal(deny(path.join(vault, 'token'), first).denied, false, 'and dropping it narrows back')
  assert.equal(deny(path.join(vault, 'token'), undefined, { [DENY_ENV]: vault }).denied, true, 'an absolute entry needs no home')
}))

await test('a link created after the cache was warmed is still refused, and a reset rebuilds', () => withHome('credential-cache-link', async root => {
  const home = path.join(root, 'home')
  fs.mkdirSync(path.join(home, '.ssh'), { recursive: true })
  resetCredentialCache()
  // Warm the roots while the credential directory holds nothing interesting.
  assert.equal(deny(path.join(home, 'work', 'main.ts'), home).denied, false)
  const link = path.join(root, 'innocent')
  fs.symlinkSync(path.join(home, '.ssh'), link, process.platform === 'win32' ? 'junction' : 'dir')
  // The candidate is canonicalised on every call, so the *target* is followed even though the roots
  // were memoised: this is the property that keeps the cache from being a way through a junction.
  assert.equal(deny(path.join(link, 'id_ed25519'), home).denied, true)
  resetCredentialCache()
  assert.equal(deny(path.join(link, 'id_ed25519'), home).denied, true, 'a rebuilt cache answers the same')
  assert.equal(credentialRoots({ home, env: {} }).length, CREDENTIAL_SUFFIXES.length, 'no root is lost or duplicated')
}))

report('credential-cache')
