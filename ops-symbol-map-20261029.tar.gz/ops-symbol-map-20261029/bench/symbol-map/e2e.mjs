/**
 * End-to-end measurement: the tool as the model actually calls it.
 *
 * Everything else in `bench/` measures the engine. This measures the *product*: one `invoke()`
 * call through `file/worker.ts` → the in-process fence → the engine → the receipt, which is what
 * an agent pays for. It is also the only place the receipt's own bytes are counted, so the token
 * numbers below are the ones a context window really sees — including the `n|text` gutter that
 * `ops_read_files` adds, which a raw `wc -c` comparison silently omits.
 *
 * Three baselines, all from this repository:
 *
 * - **read** — what `ops_read_files` returns for the whole file: header, `line|text` rows, the
 *   revision notice. Built here from `modes/native/ranges.ts`'s format, because the native worker
 *   binary is not present in this checkout.
 * - **grep** — what `ops_grep` returns for the declaration pattern: one `path:line:text` row per
 *   hit, no end line and no type. The cheapest possible "find the symbols" answer, so it is the
 *   hardest baseline for the map to beat.
 * - **map** — `invoke('symbol_map')`, whole receipt, cold and warm.
 *
 * Usage: node bench/symbol-map/e2e.mjs [--json]
 *
 * @module dsh-ops/bench/symbol-map/e2e
 */

import { createHash } from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { performance } from 'node:perf_hooks'
import { fileURLToPath } from 'node:url'

import { getEncoding } from 'js-tiktoken'

import { invoke } from '../../lib/file/worker.js'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const REPO = path.resolve(HERE, '../..')
const JSON_ONLY = process.argv.includes('--json')

const encoder = getEncoding('cl100k_base')
const tokenCache = new Map()
const tokens = (text) => {
  const hit = tokenCache.get(text)
  if (hit !== undefined) return hit
  const count = encoder.encode(text).length
  tokenCache.set(text, count)
  return count
}

const median = (values) => {
  if (values.length === 0) return null
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}

/* ------------------------------------------------------------------ bridge */

let sessions = 0

/**
 * The minimal host a real `invoke()` needs, copied in shape from `test/symbol-map.test.mjs`.
 *
 * No subprocess service: `symbol_map` is the tool that answers without one, and adding a fake
 * spawner would hide the property this whole path exists for. `mode: read-only` is the strictest
 * policy, so a successful call also proves the map does not need write authority.
 */
function bridge(workspace) {
  sessions += 1
  const ctx = { get: name => ({ sandboxPolicy: { resolve: () => ({ mode: 'read-only', workspaceRoot: workspace }) } })[name] }
  const exec = { agent: { session: { id: `e2e-${sessions}`, header: { cwd: workspace } } } }
  return { call: (tool, args) => invoke(ctx, '', tool, args, exec, undefined, { denyCredentialReads: true }) }
}

/* ------------------------------------------------------------------ corpus */

/** Largest `.ts` files under `src/`, the same corpus the other benchmarks use. */
function corpus(limit = 24) {
  const found = []
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name)
      if (entry.isDirectory()) { walk(full); continue }
      if (!entry.name.endsWith('.ts')) continue
      found.push({ path: full, bytes: fs.statSync(full).size })
    }
  }
  walk(path.join(REPO, 'src'))
  return found.sort((a, b) => b.bytes - a.bytes).slice(0, limit)
}

/* -------------------------------------------------------------- baselines */

/** Exactly `compactRanges`'s shape for one fully-returned file. */
function readPayload(rel, text) {
  const lines = text.split('\n')
  const revision = createHash('sha256').update(fs.readFileSync(path.join(REPO, rel))).digest('hex')
  const body = lines.map((line, index) => `${index + 1}|${line}`)
  return [
    `=== FILE: ${JSON.stringify(rel)} (Lines 1-${lines.length} of ${lines.length}) ===`,
    ...body,
    `[revision=${revision}; end of file; complete=true]`,
    '[Notice: 1/1 requested ranges returned.]',
  ].join('\n')
}

/** The declaration pattern a caller would have to write to find symbols with `ops_grep`. */
const DECLARATION = /^\s*(?:export\s+)?(?:default\s+)?(?:declare\s+)?(?:abstract\s+)?(?:async\s+)?(?:function\*?|class)\s+[A-Za-z_$]/

/** `ops_grep` output for that pattern: one row per match, nothing else. */
function grepPayload(rel, text) {
  const rows = []
  text.split('\n').forEach((line, index) => {
    if (DECLARATION.test(line)) rows.push(`${rel}:${index + 1}:${line.trim()}`)
  })
  return rows.join('\n')
}

/** A regex scan is what `ops_grep` compiles down to; the cost of the JS equivalent bounds it. */
function grepTime(text, reps = 5) {
  const samples = []
  for (let i = 0; i < reps; i += 1) {
    const t0 = performance.now()
    let hits = 0
    for (const line of text.split('\n')) if (DECLARATION.test(line)) hits += 1
    samples.push(performance.now() - t0 + hits * 0)
  }
  return median(samples)
}

/* -------------------------------------------------------------------- run */

const { resetCaches } = await import('../../lib/symbol-map/cache.js')

const files = corpus()
const call = bridge(REPO).call
const rows = []
const failures = []

for (const file of files) {
  const rel = path.relative(REPO, file.path).split(path.sep).join('/')
  const text = fs.readFileSync(file.path, 'utf8')
  const lines = text.split('\n')

  // Cold: a fresh cache, so the call pays for the parse. Warm: the cache hit an agent sees on the
  // second and every later turn.
  const cold = []
  const warm = []
  let receipt
  for (let rep = 0; rep < 5; rep += 1) {
    resetCaches()
    const t0 = performance.now()
    receipt = await call('symbol_map', { path: rel })
    cold.push(performance.now() - t0)
  }
  for (let rep = 0; rep < 7; rep += 1) {
    const t0 = performance.now()
    const again = await call('symbol_map', { path: rel })
    warm.push(performance.now() - t0)
    if (JSON.stringify(again.symbols) !== JSON.stringify(receipt.symbols)) {
      failures.push(`${rel}: a cached call disagreed with the cold call`)
    }
  }

  /* ---- contract, checked against the bytes on disk rather than against the engine ---- */
  const revision = createHash('sha256').update(fs.readFileSync(file.path)).digest('hex')
  if (receipt.revision !== revision) failures.push(`${rel}: revision ${receipt.revision} is not the file's sha256`)
  if (receipt.status !== 'completed') failures.push(`${rel}: status ${receipt.status} for a ${lines.length}-line file`)
  if (receipt.symbols.length !== receipt.total) failures.push(`${rel}: total ${receipt.total} but ${receipt.symbols.length} rows`)
  for (const entry of receipt.symbols) {
    const match = /^(\d+)(?:-(\d+))? ([fcm]) (.+)$/u.exec(entry)
    if (match === null) { failures.push(`${rel}: unparseable symbol ${JSON.stringify(entry)}`); continue }
    const start = Number(match[1])
    const end = match[2] === undefined ? start : Number(match[2])
    const kind = match[3]
    const name = match[4]
    if (start < 1 || end < start || end > lines.length) failures.push(`${rel}: ${name} has range ${start}-${end} outside 1-${lines.length}`)
    const opener = lines[start - 1] ?? ''
    const looksRight = kind === 'c' ? /\bclass\b/.test(opener) : kind === 'f' ? /\bfunction\b/.test(opener) : /\(|^\s*(?:static\s+)?(?:get|set)\b/.test(opener)
    if (!looksRight) failures.push(`${rel}: ${name} claims line ${start}, which reads ${JSON.stringify(opener.slice(0, 60))}`)
    if (entry.includes('\n')) failures.push(`${rel}: ${name} carries a newline`)
  }

  /* ---- payload ---- */
  const readText = readPayload(rel, text)
  const grepText = grepPayload(rel, text)
  const mapText = JSON.stringify(receipt)

  // The agent loop this feature exists for: find the one symbol, then read only it. The symbol is
  // the *median* one by span, not the largest: reading a 400-line class is a different job from
  // reading a 12-line method, and the largest span would flatter the read baseline instead.
  const spans = receipt.symbols.map((entry) => {
    const match = /^(\d+)(?:-(\d+))? [fcm] (.+)$/u.exec(entry)
    return { name: match[3], start: Number(match[1]), end: match[2] === undefined ? Number(match[1]) : Number(match[2]) }
  }).sort((a, b) => (a.end - a.start) - (b.end - b.start))
  const target = spans[Math.floor(spans.length / 2)]
  const spanText = target === undefined ? '' : lines.slice(target.start - 1, target.end).map((line, index) => `${target.start + index}|${line}`).join('\n')

  rows.push({
    file: rel,
    lines: lines.length,
    symbols: receipt.symbols.length,
    mapTokens: tokens(mapText),
    readTokens: tokens(readText),
    grepTokens: grepText === '' ? 0 : tokens(grepText),
    navigateTokens: tokens(mapText) + (spanText === '' ? 0 : tokens(spanText)),
    coldMs: median(cold),
    warmMs: median(warm),
    grepMs: grepTime(text),
    target: target === undefined ? null : `${target.name} ${target.start}-${target.end}`,
  })
}

const sum = (key) => rows.reduce((total, row) => total + row[key], 0)
const total = {
  files: rows.length,
  lines: sum('lines'),
  symbols: sum('symbols'),
  mapTokens: sum('mapTokens'),
  readTokens: sum('readTokens'),
  grepTokens: sum('grepTokens'),
  navigateTokens: sum('navigateTokens'),
  coldMs: sum('coldMs'),
  warmMs: sum('warmMs'),
  grepMs: sum('grepMs'),
}

const result = { run: new Date().toISOString(), node: process.version, platform: `${process.platform}-${process.arch}`, total, rows, failures }

if (JSON_ONLY) {
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`)
} else {
  const lines = []
  lines.push('# Symbol Map — end-to-end', '')
  lines.push(`Run: ${result.run} · node ${result.node} · ${result.platform}`)
  lines.push('', '`invoke()` through `file/worker.ts`, `mode: read-only`, no subprocess service. `read` and `grep` payloads are built from the formats `modes/native/ranges.ts` and `ops_grep` emit.', '')
  lines.push('| file | lines | sym | map tok | read tok | map/read | grep tok | map/grep | cold ms | warm ms |')
  lines.push('| ---- | ----- | --- | ------- | -------- | -------- | -------- | -------- | ------- | ------- |')
  for (const row of rows) {
    lines.push(`| \`${row.file}\` | ${row.lines} | ${row.symbols} | ${row.mapTokens} | ${row.readTokens} | ${(row.mapTokens / row.readTokens * 100).toFixed(1)}% | ${row.grepTokens} | ${row.grepTokens === 0 ? '—' : (row.mapTokens / row.grepTokens * 100).toFixed(0) + '%'} | ${row.coldMs.toFixed(2)} | ${row.warmMs.toFixed(3)} |`)
  }
  lines.push(`| **total** | **${total.lines}** | **${total.symbols}** | **${total.mapTokens}** | **${total.readTokens}** | **${(total.mapTokens / total.readTokens * 100).toFixed(1)}%** | **${total.grepTokens}** | **${(total.mapTokens / total.grepTokens * 100).toFixed(0)}%** | **${total.coldMs.toFixed(1)}** | **${total.warmMs.toFixed(2)}** |`)
  lines.push('')
  lines.push(`map vs read: **${(total.readTokens / total.mapTokens).toFixed(1)}× smaller** · map vs grep: **${(total.grepTokens / total.mapTokens).toFixed(2)}×** · navigate-then-read: **${total.navigateTokens} tok (${(total.navigateTokens / total.readTokens * 100).toFixed(1)}% of a full read)**`)
  lines.push('')
  lines.push(`cold ${total.coldMs.toFixed(1)} ms for ${rows.length} calls (${(total.coldMs / rows.length).toFixed(2)} ms/file) · warm ${total.warmMs.toFixed(2)} ms total (${(total.warmMs / rows.length * 1000).toFixed(1)} µs/file) · warm speedup ${(total.coldMs / total.warmMs).toFixed(0)}×`)
  lines.push('')
  lines.push(failures.length === 0 ? 'Contract: 0 failures.' : `Contract: ${failures.length} FAILURES\n\n${failures.slice(0, 20).map(f => `- ${f}`).join('\n')}`)
  process.stdout.write(`${lines.join('\n')}\n`)
}

fs.writeFileSync(path.join(HERE, 'e2e.json'), `${JSON.stringify(result, null, 2)}\n`)
process.exit(failures.length === 0 ? 0 : 1)
