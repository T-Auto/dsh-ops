/**
 * Symbol-map benchmark: where the milliseconds actually go, and what the map buys in tokens.
 *
 * Two questions, measured separately so neither can hide behind the other:
 *
 * 1. **Latency.** `mapSource` is split into its stages (read / parse / query / hash) so the cost
 *    of each is visible. Anything that lives in the JS wrapper is a candidate for a native
 *    rewrite; anything that lives inside the C parser is not, because a Rust rewrite calls the
 *    same parser. The stage split is what makes that boundary measurable instead of arguable.
 * 2. **Payload.** A symbol map replaces "read the whole file" with "read a line-number table".
 *    The ratio is computed with the real tokenizer (`js-tiktoken`, cl100k_base) over the real
 *    bytes, not with a character estimate.
 *
 * Nothing here asserts a duration: timings are printed and archived, never gated on. Exit code
 * stays 0 unless the engine itself throws.
 *
 * Usage:
 *   node bench/symbol-map/bench.mjs                 # full run, writes last.json + report.md
 *   node bench/symbol-map/bench.mjs --quick         # smaller corpus, fewer reps
 *   node bench/symbol-map/bench.mjs --json          # stdout JSON only
 *
 * @module dsh-ops/bench/symbol-map
 */

import { createHash } from 'node:crypto'
import fs from 'node:fs'
import path from 'node:path'
import { performance } from 'node:perf_hooks'
import { fileURLToPath } from 'node:url'

import { getEncoding } from 'js-tiktoken'

import {
  countSyntaxErrors,
  encodeSymbol,
  extractSymbols,
  getSymbolMap,
  mapSource,
  resetCaches,
  stats,
} from '../../lib/symbol-map/index.js'
// `getParser` / `getQuery` / `resetPools` are deliberately not on the public surface: the tool
// never needs them. A benchmark that wants the stages separately does, so it reaches one module
// lower instead of widening the package API for a measurement.
import { getParser, getQuery, resetPools } from '../../lib/symbol-map/grammar.js'
import { walkSymbols } from '../../lib/symbol-map/walk.js'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const REPO = path.resolve(HERE, '../..')
const OUT = path.join(HERE, 'last.json')
const MD = path.join(HERE, 'report.md')

const QUICK = process.argv.includes('--quick')
const JSON_ONLY = process.argv.includes('--json')

/* ------------------------------------------------------------------ timing */

/** Median of the samples, which is what a reader wants from a machine with a noisy clock. */
function median(values) {
  if (values.length === 0) return null
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}

/**
 * Time `fn` `reps` times after `warmup` untimed calls.
 *
 * The warmup is not politeness: the first call into a pooled parser pays for the grammar's lazy
 * lexer init, and folding that into the median would misreport steady-state cost by an order of
 * magnitude on small files.
 */
function timeIt(fn, reps, warmup = 3) {
  for (let i = 0; i < warmup; i += 1) fn()
  const samples = []
  for (let i = 0; i < reps; i += 1) {
    const t0 = performance.now()
    fn()
    samples.push(performance.now() - t0)
  }
  return { median: median(samples), min: Math.min(...samples), max: Math.max(...samples), reps }
}

const round = value => (value === null ? null : Math.round(value * 1000) / 1000)

/* ------------------------------------------------------------------- token */

const encoder = getEncoding('cl100k_base')
const tokenCache = new Map()

/** Token count, memoised: the tokenizer is the slowest thing in this script. */
function tokens(text) {
  const hit = tokenCache.get(text)
  if (hit !== undefined) return hit
  const count = encoder.encode(text).length
  tokenCache.set(text, count)
  return count
}

/* ------------------------------------------------------------------ corpus */

/** Deterministic PRNG, so two runs of this file measure the same bytes. */
function mulberry32(seed) {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6D2B79F5) >>> 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/**
 * A synthetic TypeScript module with a controlled symbol count.
 *
 * The shape matters: methods inside classes and functions at top level exercise all three query
 * patterns, and the bodies are long enough that the parser has real work to do rather than a
 * table of one-line stubs.
 */
function synthModule({ classes, functions, methodsPerClass, bodyLines }, seed) {
  const rand = mulberry32(seed)
  const out = []
  const body = indent => {
    const lines = []
    for (let i = 0; i < bodyLines; i += 1) {
      const n = Math.floor(rand() * 1000)
      lines.push(`${indent}const v${i} = ${n} * ${i + 1} + Math.max(${n}, ${i})`)
    }
    lines.push(`${indent}return v0 + v${Math.max(0, bodyLines - 1)}`)
    return lines
  }
  for (let f = 0; f < functions; f += 1) {
    out.push(`export function fn${f}(input: number): number {`)
    out.push(...body('  '))
    out.push('}')
    out.push('')
  }
  for (let c = 0; c < classes; c += 1) {
    out.push(`export class Svc${c} {`)
    out.push('  private state = 0')
    for (let m = 0; m < methodsPerClass; m += 1) {
      out.push(`  method${m}(arg: number): number {`)
      out.push(...body('    '))
      out.push('  }')
      out.push('')
    }
    out.push('}')
    out.push('')
  }
  return out.join('\n')
}

/**
 * Break a file in the way a human breaks one: an unclosed brace, a stray token, a truncated call.
 *
 * Injected at line boundaries so the damage is where a person would leave it — mid-file, not in
 * the first or last statement, which is the case tree-sitter's own recovery handles cheaply.
 */
function injectErrors(source, count) {
  const lines = source.split('\n')
  const rand = mulberry32(0xC0FFEE ^ count)
  const edits = [
    line => line.replace(/\}\s*$/, ''),
    line => `${line} @@@`,
    line => `${line}(`,
  ]
  let applied = 0
  let guard = 0
  while (applied < count && guard < count * 80) {
    guard += 1
    const at = Math.floor(lines.length * (0.15 + 0.7 * rand()))
    // A blank line cannot be broken, and `replace` on a line that does not end with `}` is a
    // no-op — both would leave a clean file and silently report a recovery cost of zero.
    if (lines[at] === undefined || lines[at].trim() === '') continue
    for (let probe = 0; probe < edits.length; probe += 1) {
      const edit = edits[(applied + probe) % edits.length]
      const next = edit(lines[at])
      if (next !== lines[at]) {
        lines[at] = next
        applied += 1
        break
      }
    }
  }
  return lines.join('\n')
}

/** Real source files from this repository, largest first, as the "believable" corpus. */
function realFiles() {
  const roots = ['src', 'lib'].map(dir => path.join(REPO, dir))
  const found = []
  const walk = dir => {
    let entries
    try { entries = fs.readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const entry of entries) {
      const full = path.join(dir, entry.name)
      if (entry.isDirectory()) { walk(full); continue }
      if (!entry.name.endsWith('.ts')) continue
      const size = fs.statSync(full).size
      found.push({ path: full, bytes: size })
    }
  }
  for (const root of roots) walk(root)
  return found.sort((a, b) => b.bytes - a.bytes)
}

/* ------------------------------------------------------------------ stages */

/**
 * Time each stage of `mapSource` separately.
 *
 * The stages are re-derived here rather than instrumented inside the engine, because timing code
 * in a hot path changes the thing it measures. `parser.parse` is the whole native parse; the
 * query stage is `matches` plus capture extraction, which is where every JS↔native boundary
 * crossing happens.
 */
function profile(source, lang = 'typescript', reps = 20) {
  const buffer = Buffer.from(source, 'utf8')
  const text = buffer.toString('utf8')
  const parser = getParser(lang)
  const query = getQuery(lang, false)

  const parse = timeIt(() => parser.parse(text), reps)
  const tree = parser.parse(text)
  const queryOnly = timeIt(() => query.matches(tree.rootNode), reps)
  const extract = timeIt(() => extractSymbols(tree, query), reps)
  const walkOnly = timeIt(() => walkSymbols(tree), reps)
  const hash = timeIt(() => createHash('sha256').update(buffer).digest('hex'), reps)
  const full = timeIt(() => mapSource(buffer, { lang }), reps)
  const errors = tree.rootNode.hasError === true
    ? timeIt(() => countSyntaxErrors(tree.rootNode), Math.max(3, Math.floor(reps / 4)))
    : null

  return {
    parseMs: parse.median,
    queryMs: queryOnly.median,
    extractMs: extract.median,
    walkMs: walkOnly.median,
    hashMs: hash.median,
    fullMs: full.median,
    errorScanMs: errors === null ? null : errors.median,
    reps,
  }
}

/**
 * The payload comparison: what a full read costs versus what the map costs.
 *
 * `fullTokens` is the whole file as the model would receive it. `mapTokens` is the serialized
 * `SymbolMap` with the symbol array only — the identity fields (`revision`, `hash`, `bytes`) are
 * counted too, because a real caller receives them.
 */
function payload(source, lang = 'typescript') {
  const buffer = Buffer.from(source, 'utf8')
  const map = mapSource(buffer, { lang })
  const encoded = map.symbols.map(encodeSymbol)
  // What the caller receives: one encoded line per symbol, not an object with four field names.
  const mapJson = JSON.stringify({ file: map.file, symbols: encoded })
  const mapJsonFull = JSON.stringify({ ...map, symbols: encoded })
  // And what the native projection prints, so the token number is not a JSON artefact.
  const native = ['=== SYMBOLS: ' + map.file + ' (' + map.lang + ', ' + map.total + ' symbols) ===',
    '[Notice: revision=' + map.revision + '; bytes=' + map.bytes + '.]',
    ...encoded].join('\n')
  return {
    bytes: buffer.length,
    lines: source.split('\n').length,
    symbols: map.total,
    partial: map.partial,
    fullTokens: tokens(source),
    mapTokens: tokens(mapJson),
    mapTokensWithIdentity: tokens(mapJsonFull),
    nativeTokens: tokens(native),
    overheadTokens: tokens(mapJsonFull) - tokens(mapJson),
  }
}

/* -------------------------------------------------------------------- runs */

function scenarioReal() {
  const files = realFiles()
  const picks = QUICK ? files.slice(0, 6) : files.slice(0, 24)
  const rows = []
  for (const file of picks) {
    const source = fs.readFileSync(file.path, 'utf8')
    const rel = path.relative(REPO, file.path).replace(/\\/g, '/')
    rows.push({ name: rel, ...payload(source), ...profile(source, 'typescript', QUICK ? 8 : 20) })
  }
  return rows
}

function scenarioScale() {
  const shapes = QUICK
    ? [{ label: '2k', classes: 8, functions: 10, methodsPerClass: 4, bodyLines: 6 }]
    : [
        { label: '1k', classes: 4, functions: 6, methodsPerClass: 3, bodyLines: 5 },
        { label: '5k', classes: 20, functions: 30, methodsPerClass: 5, bodyLines: 8 },
        { label: '20k', classes: 80, functions: 120, methodsPerClass: 6, bodyLines: 10 },
        { label: '50k', classes: 200, functions: 300, methodsPerClass: 6, bodyLines: 10 },
      ]
  const rows = []
  for (const shape of shapes) {
    const source = synthModule(shape, 1234 + shape.label.length)
    const reps = QUICK ? 5 : (shape.label === '50k' ? 5 : 10)
    rows.push({ name: `synthetic-${shape.label}`, ...payload(source), ...profile(source, 'typescript', reps) })
  }
  return rows
}

function scenarioBroken() {
  const base = synthModule({ classes: 20, functions: 30, methodsPerClass: 5, bodyLines: 8 }, 4242)
  const rows = []
  for (const count of QUICK ? [1] : [1, 3, 10, 40]) {
    const source = injectErrors(base, count)
    const row = { name: `broken-${count}`, ...payload(source), ...profile(source, 'typescript', 5) }
    const map = mapSource(source, { lang: 'typescript' })
    row.partial = map.partial
    row.recoveredSymbols = map.total
    row.syntaxErrors = map.syntaxErrors ?? null
    // What the recovery pass actually buys, in both symbols and milliseconds. Without this
    // pair a reader cannot tell "recovery is free" from "recovery was switched off". A single
    // sample is not enough: the run right after a full map lands in a different GC state and
    // reported the un-recovered build as *slower*, which is impossible.
    const bareSamples = []
    let bare = mapSource(source, { lang: 'typescript', recover: false })
    for (let attempt = 0; attempt < 5; attempt += 1) {
      resetCaches()
      const bareStart = performance.now()
      bare = mapSource(source, { lang: 'typescript', recover: false })
      bareSamples.push(performance.now() - bareStart)
    }
    row.bareMs = median(bareSamples)
    row.bareSymbols = bare.total
    rows.push(row)
  }
  return rows
}

/**
 * The path a real caller takes: `getSymbolMap` over a directory, twice.
 *
 * Everything above measures `mapSource`, which parses from scratch every time — the honest worst
 * case, and the one that makes the map look 20× slower than `ops_read_files`. The tool never calls
 * it that way. It calls `getSymbolMap`, which hashes the bytes and returns the stored map when the
 * revision still matches. The second column is what an agent actually pays on the second and later
 * `symbol_map` requests in a session, which is most of them.
 */
function scenarioToolPath() {
  const picks = realFiles().slice(0, QUICK ? 6 : 24)
  resetCaches()
  resetPools()
  const coldStart = performance.now()
  const coldMaps = picks.map(file => getSymbolMap(file.path, { lang: 'typescript' }))
  const coldMs = performance.now() - coldStart
  // The warm pass is repeated and reported as a median: a single 24-file sweep varies by 4x run to
  // run on a machine with a background compiler, which is not a property of the code.
  const warmSamples = []
  let warmMaps = []
  for (let attempt = 0; attempt < 7; attempt += 1) {
    const warmStart = performance.now()
    warmMaps = picks.map(file => getSymbolMap(file.path, { lang: 'typescript' }))
    warmSamples.push(performance.now() - warmStart)
  }
  warmSamples.sort((a, b) => a - b)
  const warmMs = warmSamples[Math.floor(warmSamples.length / 2)]
  const hits = warmMaps.filter(map => map.cacheHit === true).length
  return {
    files: picks.length,
    bytes: picks.reduce((sum, file) => sum + file.bytes, 0),
    coldMs: Math.round(coldMs * 1000) / 1000,
    warmMs: Math.round(warmMs * 1000) / 1000,
    hits,
    symbols: coldMaps.reduce((sum, map) => sum + map.total, 0),
    speedup: warmMs > 0 ? Math.round((coldMs / warmMs) * 10) / 10 : null,
  }
}

/** Where the map stops being cheaper than the file.
 *
 * Small files lose: the map carries a fixed identity header, so below some size "just read it"
 * wins on tokens. Finding that crossover is the point of this scenario — it decides when an
 * agent should skip the map entirely.
 */
function scenarioCrossover() {
  const rows = []
  const sizes = QUICK ? [10, 40] : [10, 20, 40, 60, 100, 150, 200, 300, 500]
  for (const size of sizes) {
    const bodyLines = Math.max(1, Math.floor(size / 4))
    const source = synthModule({ classes: 2, functions: 3, methodsPerClass: 3, bodyLines }, 777 + size)
    const p = payload(source)
    rows.push({
      targetLines: size,
      lines: p.lines,
      symbols: p.symbols,
      fullTokens: p.fullTokens,
      mapTokens: p.mapTokensWithIdentity,
      ratio: p.fullTokens === 0 ? null : Math.round((p.mapTokensWithIdentity / p.fullTokens) * 1000) / 1000,
    })
  }
  return rows
}

/**
 * How much the `extended` tier adds: `const handler = () => {}` is invisible to the core query.
 *
 * This is a coverage measurement, not a speed one. It answers "does the map show me the code that
 * actually runs in this file", which is the question a reader has when the core map comes back
 * with one symbol for a 340-line module.
 */
function scenarioTiers() {
  const files = realFiles().slice(0, QUICK ? 4 : 12)
  const rows = []
  for (const file of files) {
    const source = fs.readFileSync(file.path, 'utf8')
    const rel = path.relative(REPO, file.path).replace(/\\/g, '/')
    const core = mapSource(source, { lang: 'typescript' })
    const ext = mapSource(source, { lang: 'typescript', extended: true })
    rows.push({
      name: rel,
      lines: source.split('\n').length,
      coreSymbols: core.total,
      extSymbols: ext.total,
      added: ext.total - core.total,
      coreTokens: tokens(JSON.stringify({ file: core.file, symbols: core.symbols })),
      extTokens: tokens(JSON.stringify({ file: ext.file, symbols: ext.symbols })),
    })
  }
  return rows
}

/**
 * What the cached tree buys: after a one-line edit, only the changed subtree is re-parsed.
 *
 * The edit target rotates on every repetition so no measurement can be satisfied by a cache hit;
 * `getSymbolMap` reads the file, so a rewritten file always has a new revision.
 */
function scenarioIncremental() {
  const shapes = QUICK
    ? [{ label: '5k', classes: 20, functions: 30, methodsPerClass: 5, bodyLines: 8 }]
    : [
        { label: '5k', classes: 20, functions: 30, methodsPerClass: 5, bodyLines: 8 },
        { label: '20k', classes: 80, functions: 120, methodsPerClass: 6, bodyLines: 10 },
      ]
  const rows = []
  for (const shape of shapes) {
    const source = synthModule(shape, 555 + shape.label.length)
    const dir = fs.mkdtempSync(path.join(process.env.TEMP ?? '/tmp', 'smapinc-'))
    const file = path.join(dir, 'inc.ts')
    fs.writeFileSync(file, source)
    const base = source.split('\n')
    let tick = 0
    const rewrite = () => {
      const lines = [...base]
      const at = 20 + (tick * 37) % Math.max(1, lines.length - 40)
      lines[at] = `${lines[at]} `
      tick += 1
      fs.writeFileSync(file, lines.join('\n'))
    }

    resetCaches()
    const coldStart = performance.now()
    getSymbolMap(file, { lang: 'typescript' })
    const coldMs = performance.now() - coldStart

    const measure = (body, reps) => {
      const samples = []
      for (let i = 0; i < reps; i += 1) {
        rewrite()
        const t0 = performance.now()
        body()
        samples.push(performance.now() - t0)
      }
      return median(samples)
    }

    const incrementalMs = measure(() => getSymbolMap(file, { lang: 'typescript' }), QUICK ? 5 : 8)
    const forcedMs = measure(() => getSymbolMap(file, { lang: 'typescript', force: true }), QUICK ? 5 : 8)
    fs.rmSync(dir, { recursive: true, force: true })
    rows.push({
      name: `incremental-${shape.label}`,
      lines: base.length,
      coldMs,
      incrementalMs,
      forcedMs,
      speedup: incrementalMs > 0 ? Math.round((forcedMs / incrementalMs) * 10) / 10 : null,
    })
  }
  return rows
}

/** Prove the process cache does what it claims: second call must not parse again. */
function scenarioCache() {
  const source = synthModule({ classes: 10, functions: 10, methodsPerClass: 4, bodyLines: 6 }, 99)
  const dir = fs.mkdtempSync(path.join(process.env.TEMP ?? '/tmp', 'smapbench-'))
  const file = path.join(dir, 'mod.ts')
  fs.writeFileSync(file, source)
  // A cold reading has to start from an empty cache every time. Repeated calls in one process
  // would drift towards the warm number after the first, which is how an earlier version of this
  // scenario reported 0.009 ms as the cold cost.
  const coldSamples = []
  for (let attempt = 0; attempt < 5; attempt += 1) {
    resetCaches()
    resetPools()
    const t0 = performance.now()
    getSymbolMap(file, { lang: 'typescript' })
    coldSamples.push(performance.now() - t0)
  }
  const coldMs = median(coldSamples)
  const warm = timeIt(() => getSymbolMap(file, { lang: 'typescript' }), 50, 2)
  const after = stats()
  fs.rmSync(dir, { recursive: true, force: true })
  return {
    coldMs,
    warmMs: warm.median,
    speedup: coldMs !== null && warm.median ? Math.round((coldMs / warm.median) * 10) / 10 : null,
    parses: after.parses,
  }
}

/* ---------------------------------------------------------------- analysis */

/**
 * How much of `mapSource` is JS-side work that a native rewrite could remove.
 *
 * `parseMs` is the C parser, which a Rust port would also pay. Everything above it in the call
 * stack (query capture marshalling, line extraction, hashing, JSON shape) is what moves to native
 * — that fraction is the ceiling on a rewrite's payoff, not a prediction of it.
 */
function nativeCeiling(rows) {
  const usable = rows.filter(row => row.fullMs > 0 && row.parseMs !== null)
  if (usable.length === 0) return null
  const fractions = usable.map(row => Math.max(0, (row.fullMs - row.parseMs) / row.fullMs))
  return {
    samples: usable.length,
    jsShareMedian: Math.round(median(fractions) * 1000) / 1000,
    jsShareMax: Math.round(Math.max(...fractions) * 1000) / 1000,
    jsShareMin: Math.round(Math.min(...fractions) * 1000) / 1000,
    impliedMaxSpeedupMedian: Math.round((1 / (1 - median(fractions))) * 100) / 100,
  }
}

/* ------------------------------------------------------------------ report */

const pad = (value, width) => String(value).padStart(width)

function table(headers, rows) {
  const head = `| ${headers.join(' | ')} |`
  const rule = `| ${headers.map(h => '-'.repeat(Math.max(3, h.length))).join(' | ')} |`
  return [head, rule, ...rows.map(cells => `| ${cells.join(' | ')} |`)].join('\n')
}

function renderMarkdown(result) {
  const { real, scale, broken, crossover, tiers, incremental, cache, toolpath, ceiling, env } = result
  const lines = []
  lines.push('# Symbol Map Benchmark')
  lines.push('')
  lines.push(`Run: ${env.stamp} · node ${env.node} · ${env.platform} · quick=${env.quick}`)
  lines.push('')
  lines.push('## 1. Payload: map vs full read')
  lines.push('')
  lines.push('Token counts from `js-tiktoken` (cl100k_base) over the exact bytes. `mapTokens` includes the identity header the tool really returns.')
  lines.push('')
  const realRows = real.map(row => [
    `\`${row.name}\``, row.lines, row.symbols, row.fullTokens, row.mapTokensWithIdentity,
    `${Math.round((row.mapTokensWithIdentity / row.fullTokens) * 1000) / 10}%`,
  ])
  lines.push(table(['file', 'lines', 'symbols', 'full tok', 'map tok', 'map/full'], realRows))
  lines.push('')
  lines.push('## 2. Latency by stage (median ms)')
  lines.push('')
  const latRows = [...real, ...scale].map(row => [
    `\`${row.name}\``, row.lines, row.symbols,
    round(row.parseMs), round(row.queryMs), round(row.extractMs), round(row.hashMs), round(row.fullMs),
    row.errorScanMs === null ? '—' : round(row.errorScanMs),
  ])
  lines.push(table(['file', 'lines', 'symbols', 'parse', 'query', 'extract', 'hash', 'full map', 'error scan'], latRows))
  lines.push('')
  lines.push('## 3. Synthetic scale')
  lines.push('')
  const scaleRows = scale.map(row => [
    `\`${row.name}\``, row.lines, row.bytes, row.symbols, row.fullTokens, row.mapTokensWithIdentity,
    `${Math.round((row.mapTokensWithIdentity / row.fullTokens) * 1000) / 10}%`,
    round(row.parseMs), round(row.fullMs),
    Math.round((row.bytes / 1024 / Math.max(row.fullMs, 0.001)) * 10) / 10,
  ])
  lines.push(table(['scenario', 'lines', 'bytes', 'symbols', 'full tok', 'map tok', 'map/full', 'parse ms', 'full ms', 'KB/ms'], scaleRows))
  lines.push('')
  lines.push('## 4. Broken files (recovery cost)')
  lines.push('')
  lines.push('`recovered` is what the map reports; `bare` is the same file with `recover: false`, i.e. what the main tree alone yields. The last two columns are the price of the difference, not a comparison against another build.')
  lines.push('')
  const brokenRows = broken.map(row => [
    `\`${row.name}\``, row.partial === true ? 'yes' : 'no', row.syntaxErrors ?? '—', row.recoveredSymbols,
    round(row.parseMs), round(row.fullMs),
    row.fullMs !== null && row.parseMs !== null ? `${Math.round((row.fullMs / Math.max(row.parseMs, 0.001)) * 10) / 10}×` : '—',
    row.bareSymbols, round(row.bareMs),
    row.recoveredSymbols - row.bareSymbols, round(row.fullMs - row.bareMs),
  ])
  lines.push(table(['scenario', 'partial', 'error nodes', 'symbols', 'parse ms', 'full ms', 'full/parse', 'bare symbols', 'bare ms', '+symbols', '+ms'], brokenRows))
  lines.push('')
  lines.push('## 5. Crossover: when the map costs more than the file')
  lines.push('')
  const crossRows = crossover.map(row => [
    row.targetLines, row.lines, row.symbols, row.fullTokens, row.mapTokens, `${Math.round(row.ratio * 1000) / 10}%`,
  ])
  lines.push(table(['target lines', 'actual lines', 'symbols', 'full tok', 'map tok', 'map/full'], crossRows))
  lines.push('')
  lines.push('## 5b. Incremental re-parse after a one-line edit')
  lines.push('')
  lines.push('The cache keeps the tree, not just the map. When the revision moves the tree is edited in place and handed back to the parser, so only the changed subtree is re-parsed.')
  lines.push('')
  const incRows = incremental.map(row => [
    `\`${row.name}\``, row.lines, round(row.coldMs), round(row.incrementalMs), round(row.forcedMs),
    `${row.speedup}x`,
  ])
  lines.push(table(['scenario', 'lines', 'cold ms', 'after edit ms', 'forced full ms', 'speedup'], incRows))
  lines.push('')
  lines.push('## 6. The real tool path (`getSymbolMap`, 24 files)')
  lines.push('')
  lines.push(`Cold: **${toolpath.coldMs} ms** for ${toolpath.files} files / ${Math.round(toolpath.bytes / 1024)} KB / ${toolpath.symbols} symbols · second pass: **${toolpath.warmMs} ms** (${toolpath.hits} cache hits) · speedup ${toolpath.speedup}×`)
  lines.push('')
  lines.push('## 6. Process cache')
  lines.push('')
  lines.push(`Cold \`getSymbolMap\`: ${round(cache.coldMs)} ms · warm: ${round(cache.warmMs)} ms · speedup ${cache.speedup}× · parses recorded ${cache.parses}`)
  lines.push('')
  lines.push('## 6b. Core vs extended tier')
  lines.push('')
  lines.push('The core query sees declarations only. `const handler = () => {}` and `export default function` bound to a name need the extended tier.')
  lines.push('')
  const tierRows = tiers.map(row => [
    `\`${row.name}\``, row.lines, row.coreSymbols, row.extSymbols, row.added,
    row.coreTokens, row.extTokens,
    `${Math.round((row.extTokens / row.coreTokens) * 1000) / 10}%`,
  ])
  lines.push(table(['file', 'lines', 'core', 'extended', 'added', 'core tok', 'ext tok', 'ext/core'], tierRows))
  lines.push('')
  lines.push('## 7. Native rewrite ceiling')
  lines.push('')
  if (ceiling === null) {
    lines.push('No usable samples.')
  } else {
    lines.push(`Median JS-side share of \`mapSource\`: **${Math.round(ceiling.jsShareMedian * 100)}%** (range ${Math.round(ceiling.jsShareMin * 100)}%–${Math.round(ceiling.jsShareMax * 100)}%, n=${ceiling.samples}).`)
    lines.push('')
    lines.push(`A rewrite that moved every JS-side byte operation into Rust and left the parser untouched would cap at **${ceiling.impliedMaxSpeedupMedian}×** on the median sample. The C parse itself — the dominant term — is identical in both implementations.`)
  }
  lines.push('')
  lines.push('## Method')
  lines.push('')
  lines.push('- Stage timings are re-derived from the public engine exports; no instrumentation lives in the hot path.')
  lines.push('- `parse` is `parser.parse(text)` on a pooled parser: the whole native parse, nothing else.')
  lines.push('- `query` is `query.matches(root)`; `extract` is the full capture walk that crosses the N-API boundary per capture.')
  lines.push('- Every timing is a median after warmup; no duration is asserted, only printed.')
  lines.push('- Latency here is in-process. A real `ops_read_files` call adds worker RPC on top; that offset is roughly constant per call and does not change the ratios.')
  return `${lines.join('\n')}\n`
}

/* -------------------------------------------------------------------- main */

function main() {
  resetPools()
  resetCaches()
  const started = performance.now()

  const real = scenarioReal()
  const scale = scenarioScale()
  const broken = scenarioBroken()
  const crossover = scenarioCrossover()
  const tiers = scenarioTiers()
  const incremental = scenarioIncremental()
  const cache = scenarioCache()

  const result = {
    env: {
      stamp: new Date().toISOString(),
      node: process.version,
      platform: `${process.platform}-${process.arch}`,
      quick: QUICK,
      elapsedMs: Math.round(performance.now() - started),
    },
    real,
    scale,
    broken,
    crossover,
    tiers,
    incremental,
    cache,
    toolpath: scenarioToolPath(),
    ceiling: nativeCeiling([...real, ...scale]),
  }

  fs.writeFileSync(OUT, `${JSON.stringify(result, null, 2)}\n`)
  if (JSON_ONLY) {
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`)
    return
  }
  const markdown = renderMarkdown(result)
  fs.writeFileSync(MD, markdown)
  process.stdout.write(`${markdown}\n`)
  process.stdout.write(`\nwrote ${path.relative(REPO, OUT)} and ${path.relative(REPO, MD)} in ${result.env.elapsedMs} ms\n`)
}

main()
