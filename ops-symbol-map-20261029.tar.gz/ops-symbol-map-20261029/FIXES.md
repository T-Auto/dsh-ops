# 本地修补 — ops-symbol-map 20261028

## S1 重解析点逃逸（严重）

**位置**：`src/file/symbol-map.ts`（新增 `src/file/reparse.ts`）；编译产物 `lib/file/symbol-map.js` + `lib/file/reparse.js`

**现象**：五道围栏里，凭据围栏看的是**名字**，锚定看的是**词法路径**，两者都看不见内核在 open 时做的解析。工作区内放一个 junction 指向栏外：

```
ws/link -> K:/ai/.tmp/audit2/outside
path: "link/leak.ts"
```

名字里没有凭据关键字，词法上 `inside(workspaceRoot, ws/link/leak.ts)` 成立，于是 `statSync` + `readFileSync` 直接跟到栏外。实测返回 2 个符号（`leaked`、`Hidden`），文件内容来自工作区之外。原装 Rust 用 `open_nofollow` 拒绝这一类路径，这里是裸 `readFileSync`，等于没有这道防线。

**修补**：新增 `reparseEscape(abs, stops)`，从叶子逐级 `lstat` 到锚点（锚点自身检查、其父目录不检查——宿主自己的 profile 目录可能就是 junction）。命中即返回该组件，适配层返回 `PATH_RESTRICTED`，并把该组件 `realpath` 后再过一次凭据围栏：落到凭据根时返回 `CREDENTIAL_DENIED`，与原生同码。

```ts
const link = reparseEscape(trusted, sessionAnchors(policy, cwd))
if (link !== undefined) { /* 凭据复核 → PATH_RESTRICTED */ }
```

`PATH_RESTRICTED` 同时进 `PREFLIGHT`：拒绝发生在任何字节被读之前。

## 验证

| 用例 | 修补前 | 修补后 |
| --- | --- | --- |
| `link/leak.ts`（junction 指向栏外） | `completed`，2 个符号 | `PATH_RESTRICTED` |
| 同一路径，`danger-full-access` | 读到栏外 | `PATH_RESTRICTED`（原生同样拒绝） |
| 普通文件 `real.ts` | `completed`，3 个符号 | `completed`，3 个符号 |
| 深层真实路径（`…/dsh-ops/lib/file/ptc-inproc.js`） | ok | ok，无误杀 |
| 热态单次 | 0.06 ms | 0.20 ms |

热态多出的 ~0.14 ms 就是 6–9 次 `lstat`。这是替换路径上唯一为安全付的代价：原生同样每级 `symlink_metadata`，只是付在 Rust 里。

## 已知边界

- `anchoredPath` 仍然只 canonicalise 锚点，不 realpath 调用方的父目录——这是刻意的，配合 `reparseEscape` 之后两者互补：词法不动，重解析点单独拒。
- `authority-paths` 的锚缓存 TTL 5 s 保留：锚点是宿主所有，调用方改不动；`reparseEscape` 每次调用都重新 `lstat`，不共享缓存，因此不存在跨调用的陈旧窗口。

## R12 `lstat` 与 `open` 之间的窗口用 realpath 收口

**位置**：`src/file/symbol-map.ts`

**现象**：`reparseEscape` 走的是 `lstat` 链，真正读取由内核在 `open` 时解析。两者之间把叶子
换成 junction，`lstat` 报「普通文件」而 `open` 已跟到栏外——S1 的防线是「检查时没有链接」，
不是「读取时不可能有链接」。

**修补**：`lstat` 之后补一次 `realpathSync.native(trusted)`，把「实际要读的」折回真实路径，
再做锚点包含判定与凭据判定；不存在时交给引擎报 `NOT_FOUND`，不在这里替它定罪。窗口从
「两次 syscall 之间」收窄到「一次 realpath 之内」。热态代价 0.06 ms → 0.18–0.20 ms（多出的
就是这次 `lstat` + `realpath`，原生 Rust 侧同样要付，只是付在 `open_nofollow` 里）。

## R12 补 `package.json`：语法包改 `optionalDependencies`

**位置**：新增 `package.json`

**现象**：这份源码包此前没有任何 manifest。把它摊进 `dsh-ops/lib/symbol-map/` 后，语法包
（`tree-sitter` / `-typescript` / `-javascript`）靠手工 `npm i` 装进宿主目录；换机、重装、
`pnpm install --frozen-lockfile` 都会把它们抹掉，`symbol_map` 随即整条变成
`EXECUTOR_UNAVAILABLE`。

**修补**：声明 `optionalDependencies`（三个语法包都带原生编译，装不上时不该阻断整个安装），
并在回执的 `nextAction` 里给出确切的安装命令。语法包缺失时依旧只让 `symbol_map` 不可用，
`read_files` 等工具不受影响。

## R12 默认页大小文档纠偏

代码里 `DEFAULT_LIMIT = 512`（`src/symbol-map/snapshot.ts:20`），工具 schema 的
`limit` 描述写的是「Default 64」，README 也照抄。调用方据此算分页会多切 8 倍。三处统一成 512。
